function insertOp0()
{
if(a>=0)
{
var a=parseInt(document.getElementById("a1").value);
var sqt=Math.sqrt(a);
alert(sqt);
}
else{
    alert("invalid input!!");
}
}

function insertOp1()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
var b=parseInt(document.getElementById("b1").value);
var p=Math.pow(a,b);
alert(p);
}
else{
    alert("invalid input!!");
}
}


function insertOp2()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
var b=parseInt(document.getElementById("b1").value);
var div=a/b;
alert(div);
}
else{
    alert("invalid input!!");
}
}

function insertOp3()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
var b=parseInt(document.getElementById("b1").value);
var mul=a*b;
alert(mul);
}
else{
    alert("invalid input!!");
}
}

function insertOp4()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
var b=parseInt(document.getElementById("b1").value);
var sub=a-b;
alert(sub);
}
else{
    alert("invalid input!!");
}
}

function insertOp5()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
var b=parseInt(document.getElementById("b1").value);
var sum=a+b;
alert(sum);
}
else{
    alert("invalid input!!");
}
}

function insertOp6()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
//var b=parseInt(document.getElementById("b1").value);
var s=Math.sin(a);
alert(s);
}
else{
    alert("invalid input!!");
}
}

function insertOp7()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
//var b=parseInt(document.getElementById("b1").value);
var c=Math.cos(a);
alert(c);
}
else{
    alert("invalid input!!");
}
}

function insertOp8()
{
    if(a>=0 && b>=0)
{
var a=parseInt(document.getElementById("a1").value);
//var b=parseInt(document.getElementById("b1").value);
var t=Math.tan(a);
alert(t);
}
else{
    alert("invalid input!!");
}
}
