class A
{
	public static void main(String aman[])
	{
		System.out.print("hello \t world ");
	}

}

/*jdk java develpment kit 
path set   
	IDE(integrated development environment) : 
		ECLIPSE ,NETBEANS ,VISUAL STUDIO ETC.*/