
        document.write("hello i am inline script ");
        document.write("<h3>"+"This is a heading"+"</h3>");
       