(function($) {
	"use strict";	
	// ______________ PerfectScrollbar	
	const ps = new PerfectScrollbar('.right-sidebar', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
})(jQuery);