#include<stdio.h>
#include<conio.h>
int main()
{
 //   clrscr();
    int variable1=10;
    printf("hello world");
    getch();
    return 0;
}